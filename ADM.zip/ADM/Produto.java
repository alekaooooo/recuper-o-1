public class Produto {

    int Id;
    double PrecoFinal;
    String NomeProduto;
    int QuantProduto;


}
