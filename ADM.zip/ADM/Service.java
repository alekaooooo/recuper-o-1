public class Service {

    public void() {
        List<Usuario>
    }
}
