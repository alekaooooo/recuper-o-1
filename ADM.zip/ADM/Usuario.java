
        public class Funcionario {

            int CPF;
            String Nome;
            String Produtos;
            String PrecoTotal;
            int Perfil;


}
